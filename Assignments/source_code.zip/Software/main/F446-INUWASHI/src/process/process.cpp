#include "./process.h"

Location location;

VICTIM victim;

LCD lcd;