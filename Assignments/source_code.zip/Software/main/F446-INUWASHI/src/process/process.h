#ifndef _PROCESS_H_
#define _PROCESS_H_

#include "./location.h"
#include "./victim.h"
#include "./LCD.h"

extern Location location;
extern Route Map[200];

extern VICTIM victim;

extern LCD lcd;

#endif