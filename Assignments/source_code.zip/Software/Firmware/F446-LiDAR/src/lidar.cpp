#include "lidar.h"

LIDAR::LIDAR(HardwareSerial *_uartPtr, int _pwmPin) {
    static const int UartBaudrate = 230400;

    uartPtr = _uartPtr;
    uartPtr->begin(UartBaudrate);

    pinMode(_pwmPin, INPUT);  // 誤操作防止のためハイインピーダンスに

    for (int i = 0; i < HistogramLength; i++) {
        refWave[i] = -cos(2 * PI / (GridSize / HistogramBinWidth) * i) * 100;
    }

    return;
}

void LIDAR::read(const int _gyro) {
    // データの読み取りのために開始文字を検索
    static const int UartDataLength = 47;
    static const int UartDataStartChar = 0x54;

    while (1) {
        if (uartPtr->available() < UartDataLength) {
            return;
        }

        if (uartPtr->read() == UartDataStartChar) {
            break;
        }
    }

    // 読み取り
    char rawData[UartDataLength - 1] = {0};
    uartPtr->readBytes(rawData, UartDataLength - 1);

    // NOTE:命名は公式ドキュメントに準拠
    // https://www.notion.so/shirokuma89dev/LiDAR-LD06-6998a6b96af247ac8309316f9cc44c03?pvs=4
    const int DataLength = 12;  // Fixed value
    const int RadarSpeed = (rawData[2] << 8) + rawData[1];
    const int TimeStamp = (rawData[44] << 8) + rawData[43];
    const int CrcCheck = rawData[45];
    const double StartAngle = ((rawData[4] << 8) + rawData[3]) / 100.0;
    const double EndAngle = ((rawData[42] << 8) + rawData[41]) / 100.0;

    double leadAngle = EndAngle - StartAngle;
    if (leadAngle < 0.0) {
        leadAngle += 360.0;
    }
    const double step = leadAngle / (DataLength - 1);

    static int circularBufferIndex = 0;
    for (int i = 0; i < DataLength; i++) {
        double angle = StartAngle + step * i;
        int distance = (rawData[6 + i * 3] << 8) + rawData[5 + i * 3];
        int confidence = rawData[7 + i * 3];

        if (distance < 1200 && distance >= 200) {
            // NOTE:動径は時計周り
            point[circularBufferIndex].x =
                (double)distance * sin(radians(angle + _gyro));
            point[circularBufferIndex].y =
                (double)distance * cos(radians(angle + _gyro));

            circularBufferIndex++;
            circularBufferIndex %= DataBuffLength;

            point[circularBufferIndex].rightWallExists = true;
            point[circularBufferIndex].leftWallExists = true;

            while (angle <= 0) {
                angle += 360;
            }
            while (angle >= 360) {
                angle -= 360;
            }

            if (distance > WallRange) {
                if (angle >= WallStart && angle <= WallEnd) {
                    point[circularBufferIndex].rightWallExists = false;
                } else if (angle >= (360 - WallEnd) &&
                           angle <= (360 - WallStart)) {
                    point[circularBufferIndex].leftWallExists = false;
                }
            }
        }
    }

    return;
}

void LIDAR::updateHistogram(void) {
    for (int i = 0; i < HistogramLength; i++) {
        histogarm[i].x = 0;
        histogarm[i].y = 0;
    }

    for (int i = 0; i < DataBuffLength; i++) {
        int x = (int)point[i].x;
        int y = (int)point[i].y;

        int xIndex = (x + HistogramRange) / HistogramBinWidth;
        int yIndex = (y + HistogramRange) / HistogramBinWidth;

        // 配列外参照を防ぐ
        if (xIndex < 0 || xIndex >= HistogramLength || yIndex < 0 ||
            yIndex >= HistogramLength) {
            continue;
        }

        histogarm[xIndex].x++;
        histogarm[yIndex].y++;
    }

    return;
}

void LIDAR::calcCov(const int _phase) {
    double cov = 0;
    for (int i = 0; i < HistogramLength; i++) {
        cov += histogarm[i].x * refWave[(i + _phase) % HistogramLength];
    }
    cov /= HistogramLength;
    this->covX = cov;

    cov = 0;
    for (int i = 0; i < HistogramLength; i++) {
        cov += histogarm[i].y * refWave[(i + _phase) % HistogramLength];
    }
    cov /= HistogramLength;
    this->covY = cov;
}

void LIDAR::judgeWall(void) {
    rightWallExists = true;
    leftWallExists = true;

    int rightWallCounter = 0;
    int leftWallCounter = 0;

    for (int i = 0; i < LIDAR::DataBuffLength; i++) {
        if (!point[i].rightWallExists) {
            rightWallCounter++;
        }
        if (!point[i].leftWallExists) {
            leftWallCounter++;
        }
    }

    const int Threshold = 15;

    if (rightWallCounter > Threshold) {
        rightWallExists = false;
    }
    if (leftWallCounter > Threshold) {
        leftWallExists = false;
    }
}